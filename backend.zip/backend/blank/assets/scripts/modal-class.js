// var openmodel = document.getElementById('plus')
// var modal = document.getElementById('modal-bg')
alert("loading")

// openmodel.addEventListener(click,function(){
//     alert("clicked")
//     modal.classList.add('active')
// })